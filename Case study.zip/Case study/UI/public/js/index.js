url_emp = process.env.EMPLOYEE_MICROSERVICE
url_dpt = process.env.DEPARTMENT_MICROSERVICE


mainpage = {
    init : function(){
        console.log("Running")
        mainpage.checkdata()
    },
    checkdata:function(){
        $(".employeeinfo").on("click",function(e){
            e.preventDefault()
            console.log("clicked")
            name_val=$(".name").val()
            role=$(".role").val()
            url_gen= url_emp+"/employee?name="+name_val+"&role="+role
            console.log(url_gen)
            $.ajax({
                
                url:url_gen,
                type:"GET",
                dataType:"json",
                success:function(data){
                
                   
                   template= `<h1>${data.Status}</h1>`
                   console.log($(".showdata"))
                   $(".showdata").html(template)
                   setTimeout(() => {
                    $(".showdata").html('')
                   }, 2000);
            }
            })
        })
        $(".deptinfo").on("click",function(e){
            e.preventDefault()
            console.log("clicked")
            name_val=$(".deptempname").val()
            role=$(".deptmentname").val()
            url_gen= url_dpt+"/department?name="+name_val+"&role="+role
            console.log(url_gen)
            $.ajax({
                
                url:url_gen,
                type:"GET",
                dataType:"json",
                success:function(data){
                
                   
                   template= `<h1>${data.Status}</h1>`
                   console.log($(".showdata"))
                   $(".showdata").html(template)
                   setTimeout(() => {
                    $(".showdata").html('')
                   }, 2000);
            }
            })
        })
    }
}

$(function(){
    mainpage.init()
})